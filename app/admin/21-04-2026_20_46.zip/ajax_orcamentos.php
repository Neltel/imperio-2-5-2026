<?php
/**
 * AJAX para carregar orçamentos por cliente
 * Usado na importação de extrato bancário
 */
require_once __DIR__ . '/../../config/database.php';
session_start();

header('Content-Type: application/json');

// Verificar se o cliente_id foi enviado
if (!isset($_GET['cliente_id']) || empty($_GET['cliente_id'])) {
    echo json_encode(['error' => 'Cliente não informado', 'data' => []]);
    exit;
}

$cliente_id = intval($_GET['cliente_id']);
$orcamentos = [];

// Buscar orçamentos do cliente (pendentes ou aprovados)
$sql = "SELECT o.id, o.numero, o.valor_total, o.data_emissao, c.nome as cliente_nome 
        FROM orcamentos o 
        LEFT JOIN clientes c ON o.cliente_id = c.id 
        WHERE o.cliente_id = $cliente_id 
        AND (o.situacao = 'pendente' OR o.situacao = 'aprovado')
        ORDER BY o.id DESC 
        LIMIT 20";

$result = $conexao->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $orcamentos[] = [
            'id' => $row['id'],
            'numero' => $row['numero'],
            'valor_total' => $row['valor_total'],
            'cliente_nome' => $row['cliente_nome'],
            'display' => $row['numero'] . ' - R$ ' . number_format($row['valor_total'], 2, ',', '.')
        ];
    }
}

// Se não encontrar orçamentos, retornar array vazio
if (empty($orcamentos)) {
    echo json_encode(['message' => 'Nenhum orçamento encontrado para este cliente', 'data' => []]);
    exit;
}

echo json_encode($orcamentos);
?>