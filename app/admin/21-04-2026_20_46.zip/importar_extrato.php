<?php
/**
 * =====================================================================
 * IMPORTAÇÃO DE EXTRATO BANCÁRIO - COM IA INTERATIVA
 * =====================================================================
 */

session_start();
require_once __DIR__ . '/../../config/environment.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../classes/Auth.php';

if (!Auth::isLogado() || !Auth::isAdmin()) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

$mensagem = '';
$erro = '';
$transacoes_importadas = [];

// Função para parse de arquivo OFX (melhorada)
function parseOFX($conteudo) {
    $transacoes = [];
    
    // Extrair tags STMTTRN
    preg_match_all('/<STMTTRN>.*?<\/STMTTRN>/s', $conteudo, $matches);
    
    foreach ($matches[0] as $transacao) {
        // Extrair data
        preg_match('/<DTPOSTED>(\d{4})(\d{2})(\d{2})/', $transacao, $data_match);
        $data = $data_match ? "{$data_match[1]}-{$data_match[2]}-{$data_match[3]}" : date('Y-m-d');
        
        // Extrair valor
        preg_match('/<TRNAMT>(-?\d+\.\d+)/', $transacao, $valor_match);
        $valor = $valor_match ? floatval($valor_match[1]) : 0;
        
        // Extrair descrição (prioridade: MEMO > NAME > PAYEE)
        preg_match('/<MEMO>(.*?)<\/MEMO>/', $transacao, $memo_match);
        $descricao = $memo_match ? trim($memo_match[1]) : '';
        
        if (empty($descricao)) {
            preg_match('/<NAME>(.*?)<\/NAME>/', $transacao, $name_match);
            $descricao = $name_match ? trim($name_match[1]) : '';
        }
        
        if (empty($descricao)) {
            preg_match('/<PAYEE>(.*?)<\/PAYEE>/', $transacao, $payee_match);
            $descricao = $payee_match ? trim($payee_match[1]) : '';
        }
        
        // Limpar descrição
        $descricao = preg_replace('/\s+/', ' ', $descricao);
        $descricao = trim($descricao);
        
        if ($valor != 0 && !empty($descricao)) {
            $transacoes[] = [
                'data' => $data,
                'valor' => abs($valor),
                'tipo' => $valor < 0 ? 'saida' : 'entrada',
                'descricao' => $descricao,
                'original_descricao' => $descricao
            ];
        }
    }
    
    return $transacoes;
}

// Função para parse de CSV do Nubank
function parseCSVNubank($conteudo) {
    $transacoes = [];
    $linhas = explode("\n", $conteudo);
    
    // Pular cabeçalho
    array_shift($linhas);
    
    foreach ($linhas as $linha) {
        if (empty(trim($linha))) continue;
        
        // CSV do Nubank: data,valor,identificador,descricao
        $dados = str_getcsv($linha);
        if (count($dados) < 2) continue;
        
        $data = isset($dados[0]) ? date('Y-m-d', strtotime($dados[0])) : date('Y-m-d');
        $valor_str = str_replace(['R$', ' ', '.', ','], ['', '', '', '.'], $dados[1] ?? '0');
        $valor = floatval($valor_str);
        $descricao = $dados[3] ?? $dados[2] ?? 'Transação bancária';
        
        if ($valor != 0) {
            $transacoes[] = [
                'data' => $data,
                'valor' => abs($valor),
                'tipo' => $valor < 0 ? 'saida' : 'entrada',
                'descricao' => $descricao,
                'original_descricao' => $descricao
            ];
        }
    }
    
    return $transacoes;
}

// Função de IA para classificar transação
function iaClassificarTransacao($descricao, $valor, $tipo) {
    $desc_lower = strtolower($descricao);
    $categoria = '';
    $confianca = 0;
    $cliente_sugerido = null;
    $orcamento_sugerido = null;
    
    // Palavras-chave para categorias de SAÍDA
    $palavras_saida = [
        'materiais' => ['material', 'insumo', 'peca', 'ferramenta', 'equipamento', 'produto'],
        'fornecedores' => ['fornecedor', 'compra', 'aquisição', 'forn'],
        'funcionarios' => ['salario', 'funcionario', 'colaborador', 'pagamento func', 'holerite'],
        'impostos' => ['imposto', 'taxa', 'iptu', 'iss', 'icms', 'simples', 'das'],
        'aluguel' => ['aluguel', 'aluguer', 'locação'],
        'energia' => ['energia', 'luz', 'eletricidade', 'cpfl', 'energisa'],
        'agua' => ['agua', 'sabesp', 'sanepar'],
        'internet' => ['internet', 'telefone', 'vivo', 'claro', 'tim', 'oi', 'fibra'],
        'marketing' => ['marketing', 'publicidade', 'ads', 'google', 'facebook', 'instagram', 'anuncio']
    ];
    
    // Palavras-chave para categorias de ENTRADA
    $palavras_entrada = [
        'vendas' => ['venda', 'servico', 'instalação', 'manutencao', 'limpeza'],
        'cobrancas' => ['cobranca', 'boleto', 'parcela', 'recebimento'],
        'cliente' => ['cliente', 'pagamento', 'recebido', 'transferencia']
    ];
    
    if ($tipo == 'saida') {
        foreach ($palavras_saida as $cat => $palavras) {
            foreach ($palavras as $palavra) {
                if (strpos($desc_lower, $palavra) !== false) {
                    $categoria = $cat;
                    $confianca = 80;
                    break 2;
                }
            }
        }
        
        // Se não encontrou, tenta identificar pelo nome do estabelecimento
        if (empty($categoria)) {
            // Identificar possíveis fornecedores
            if (preg_match('/(MERCADO|SUPERMERCADO|ATACADAO|ATACADO)/i', $desc_lower)) {
                $categoria = 'materiais';
                $confianca = 60;
            } elseif (preg_match('/(HARDWARE|ELETRICA|TUBOS|COBRE|AR CONDICIONADO)/i', $desc_lower)) {
                $categoria = 'materiais';
                $confianca = 70;
            } else {
                $categoria = 'outras_saidas';
                $confianca = 30;
            }
        }
    } else {
        foreach ($palavras_entrada as $cat => $palavras) {
            foreach ($palavras as $palavra) {
                if (strpos($desc_lower, $palavra) !== false) {
                    $categoria = $cat;
                    $confianca = 80;
                    break 2;
                }
            }
        }
        
        if (empty($categoria)) {
            $categoria = 'outras_entradas';
            $confianca = 30;
        }
    }
    
    return [
        'categoria' => $categoria,
        'confianca' => $confianca,
        'cliente_sugerido' => $cliente_sugerido,
        'orcamento_sugerido' => $orcamento_sugerido
    ];
}

// Processar upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['arquivo_extrato']) && $_FILES['arquivo_extrato']['error'] === UPLOAD_ERR_OK) {
        $arquivo = $_FILES['arquivo_extrato'];
        $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
        $conteudo = file_get_contents($arquivo['tmp_name']);
        
        // Parse conforme extensão
        if ($extensao === 'ofx' || $extensao === 'ofc') {
            $transacoes_importadas = parseOFX($conteudo);
        } elseif ($extensao === 'csv') {
            $transacoes_importadas = parseCSVNubank($conteudo);
        } else {
            $erro = "Formato não suportado. Use OFX ou CSV.";
        }
        
        if (!empty($transacoes_importadas)) {
            // Aplicar IA para classificação automática
            foreach ($transacoes_importadas as &$trans) {
                $classificacao = iaClassificarTransacao($trans['descricao'], $trans['valor'], $trans['tipo']);
                $trans['categoria_sugerida'] = $classificacao['categoria'];
                $trans['confianca'] = $classificacao['confianca'];
            }
            $_SESSION['transacoes_pendentes'] = $transacoes_importadas;
            header('Location: ' . BASE_URL . '/app/admin/importar_extrato.php?acao=classificar');
            exit;
        } else {
            $erro = "Nenhuma transação encontrada no arquivo.";
        }
    }
    
    // Processar classificação individual via AJAX
    if (isset($_POST['ajax']) && $_POST['ajax'] === '1') {
        header('Content-Type: application/json');
        $descricao = $_POST['descricao'] ?? '';
        $tipo = $_POST['tipo'] ?? 'saida';
        
        $classificacao = iaClassificarTransacao($descricao, 0, $tipo);
        echo json_encode($classificacao);
        exit;
    }
    
    // Salvar classificações
    if (isset($_POST['acao']) && $_POST['acao'] === 'salvar_classificacoes') {
        $classificacoes = $_POST['classificacao'] ?? [];
        $clientes_ids = $_POST['cliente_id'] ?? [];
        $orcamentos_ids = $_POST['orcamento_id'] ?? [];
        $descricoes_personalizadas = $_POST['descricao_personalizada'] ?? [];
        
        $importadas = 0;
        
        foreach ($classificacoes as $index => $categoria) {
            if (empty($categoria)) continue;
            
            $transacao = $_SESSION['transacoes_pendentes'][$index] ?? null;
            if (!$transacao) continue;
            
            $cliente_id = !empty($clientes_ids[$index]) ? intval($clientes_ids[$index]) : 'NULL';
            $orcamento_id = !empty($orcamentos_ids[$index]) ? intval($orcamentos_ids[$index]) : 'NULL';
            
            $descricao_final = !empty($descricoes_personalizadas[$index]) 
                ? addslashes($descricoes_personalizadas[$index]) 
                : addslashes($transacao['descricao']);
            
            $observacao = "Importado do extrato bancário - Original: " . addslashes($transacao['original_descricao']);
            
            $sql = "INSERT INTO financeiro (tipo, valor, descricao, categoria, cliente_id, data_transacao, forma_pagamento, observacao) 
                    VALUES ('{$transacao['tipo']}', {$transacao['valor']}, '{$descricao_final}', '{$categoria}', {$cliente_id}, '{$transacao['data']}', 'transferencia', '{$observacao}')";
            
            if ($conexao->query($sql)) {
                $importadas++;
            }
        }
        
        unset($_SESSION['transacoes_pendentes']);
        $_SESSION['mensagem'] = "$importadas transações importadas com sucesso!";
        header('Location: ' . BASE_URL . '/app/admin/financeiro.php');
        exit;
    }
}

// Carregar dados
$clientes = [];
$sql_clientes = "SELECT id, nome, whatsapp, email FROM clientes WHERE ativo = 1 ORDER BY nome ASC";
$result = $conexao->query($sql_clientes);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $clientes[] = $row;
    }
}

$orcamentos = [];
$sql_orc = "SELECT o.id, o.numero, o.valor_total, c.nome as cliente_nome 
            FROM orcamentos o 
            LEFT JOIN clientes c ON o.cliente_id = c.id 
            WHERE o.situacao = 'pendente' OR o.situacao = 'aprovado'
            ORDER BY o.id DESC LIMIT 100";
$result = $conexao->query($sql_orc);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $orcamentos[] = $row;
    }
}

$categorias_entrada = [
    'vendas' => '💰 Venda de Produto/Serviço',
    'cobrancas' => '📄 Recebimento de Cobrança',
    'cliente' => '👤 Pagamento de Cliente',
    'outras_entradas' => '📌 Outras Entradas'
];

$categorias_saida = [
    'materiais' => '🔧 Materiais/Insumos',
    'fornecedores' => '🏭 Pagamento Fornecedor',
    'funcionarios' => '👨‍💼 Funcionários/Salários',
    'impostos' => '📊 Impostos/Taxas',
    'aluguel' => '🏠 Aluguel',
    'energia' => '⚡ Energia Elétrica',
    'agua' => '💧 Água',
    'internet' => '🌐 Internet/Telefone',
    'marketing' => '📢 Marketing/Publicidade',
    'outras_saidas' => '📌 Outras Saídas'
];

$transacoes_pendentes = $_SESSION['transacoes_pendentes'] ?? [];

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Importar Extrato Bancário - Império AR</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/style.css">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/public/css/admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #1e3c72;
            --secondary: #2a5298;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #f5f6fa 0%, #e9ecef 100%); min-height: 100vh; }
        .admin-container { display: flex; min-height: 100vh; }
        .sidebar { width: 300px; background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; padding: 20px; position: fixed; height: 100vh; z-index: 1000; overflow-y: auto; }
        .main-content { flex: 1; margin-left: 300px; padding: 30px; overflow-y: auto; }
        .page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding: 20px; background: white; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .page-header h1 { color: var(--primary); font-size: 28px; display: flex; align-items: center; gap: 10px; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; text-decoration: none; font-size: 14px; transition: all 0.3s; }
        .btn-primary { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; }
        .btn-success { background: linear-gradient(135deg, var(--success), #34ce57); color: white; }
        .btn-danger { background: linear-gradient(135deg, var(--danger), #e04b5a); color: white; }
        .btn-warning { background: linear-gradient(135deg, var(--warning), #e0a800); color: #333; }
        .btn-info { background: linear-gradient(135deg, var(--info), #138496); color: white; }
        .btn-secondary { background: #6c757d; color: white; }
        .btn-sm { padding: 6px 12px; font-size: 13px; }
        .card { background: white; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 30px; overflow: hidden; }
        .card-header { padding: 20px; background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; }
        .card-header h3 { margin: 0; font-size: 18px; display: flex; align-items: center; gap: 10px; }
        .card-body { padding: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: #333; font-size: 14px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 12px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 14px; }
        .form-group input:focus, .form-group select:focus { border-color: var(--primary); outline: none; }
        .table-responsive { overflow-x: auto; }
        .table { width: 100%; border-collapse: collapse; background: white; }
        .table thead { background: linear-gradient(135deg, var(--primary), var(--secondary)); color: white; }
        .table th { padding: 15px; text-align: left; font-weight: 600; font-size: 14px; }
        .table td { padding: 15px; border-bottom: 1px solid #e0e0e0; color: #333; }
        .badge { display: inline-block; padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 600; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-info { background: #cce5ff; color: #004085; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-high { background: #d4edda; color: #155724; }
        .badge-medium { background: #fff3cd; color: #856404; }
        .badge-low { background: #f8d7da; color: #721c24; }
        .alert { padding: 15px 20px; border-radius: 8px; margin-bottom: 25px; display: flex; align-items: center; gap: 10px; }
        .alert-success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert-error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert-info { background: #cce5ff; color: #004085; border: 1px solid #b8daff; }
        .upload-area { border: 2px dashed #dee2e6; border-radius: 12px; padding: 40px; text-align: center; cursor: pointer; transition: all 0.3s; }
        .upload-area:hover { border-color: var(--primary); background: #f8f9fa; }
        .valor-positivo { color: var(--success); font-weight: bold; }
        .valor-negativo { color: var(--danger); font-weight: bold; }
        .ia-sugestao { background: #e8f4fd; border-left: 3px solid var(--info); padding: 5px 10px; border-radius: 4px; font-size: 12px; margin-top: 5px; }
        .btn-ia { background: #6f42c1; color: white; border: none; border-radius: 4px; padding: 4px 8px; font-size: 11px; cursor: pointer; }
        @media (max-width: 768px) {
            .sidebar { width: 100%; height: auto; position: relative; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <?php include __DIR__ . '/includes/sidebar.php'; ?>

        <main class="main-content">
            
            <?php if (isset($_SESSION['mensagem'])): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $_SESSION['mensagem']; unset($_SESSION['mensagem']); ?></div>
            <?php endif; ?>

            <?php if ($erro): ?>
            <div class="alert alert-error"><i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($erro); ?></div>
            <?php endif; ?>

            <?php if (isset($_GET['acao']) && $_GET['acao'] === 'classificar' && !empty($transacoes_pendentes)): ?>
                
                <div class="page-header">
                    <h1><i class="fas fa-robot"></i> Classificar Transações</h1>
                    <div>
                        <a href="importar_extrato.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
                    </div>
                </div>

                <div class="alert alert-info">
                    <i class="fas fa-microchip"></i>
                    <strong>Classificação Inteligente (IA)</strong> - A IA analisou cada transação e pré-selecionou categorias com base na descrição.<br>
                    <strong>Confiança:</strong> 
                    <span class="badge badge-high">Alta (80%+)</span> 
                    <span class="badge badge-medium">Média (50-79%)</span> 
                    <span class="badge badge-low">Baixa (<50%)</span>
                </div>

                <form method="POST" id="form-classificar">
                    <input type="hidden" name="acao" value="salvar_classificacoes">
                    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                    
                    <div class="card">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th width="80">Data</th>
                                        <th width="300">Descrição Original</th>
                                        <th width="200">Descrição Final</th>
                                        <th width="100">Valor</th>
                                        <th width="80">Tipo</th>
                                        <th width="180">Categoria</th>
                                        <th width="180">Vincular Cliente</th>
                                        <th width="180">Vincular Orçamento</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($transacoes_pendentes as $index => $trans): 
                                        $confianca = $trans['confianca'] ?? 0;
                                        $badge_classe = $confianca >= 80 ? 'badge-high' : ($confianca >= 50 ? 'badge-medium' : 'badge-low');
                                    ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y', strtotime($trans['data'])); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($trans['descricao']); ?>
                                            <div class="ia-sugestao">
                                                <i class="fas fa-robot"></i> IA: 
                                                <strong>
                                                    <?php 
                                                    if ($trans['tipo'] == 'entrada') {
                                                        echo $categorias_entrada[$trans['categoria_sugerida']] ?? $trans['categoria_sugerida'];
                                                    } else {
                                                        echo $categorias_saida[$trans['categoria_sugerida']] ?? $trans['categoria_sugerida'];
                                                    }
                                                    ?>
                                                </strong>
                                                <span class="badge <?php echo $badge_classe; ?>" style="margin-left: 5px;"><?php echo $confianca; ?>%</span>
                                            </div>
                                        </td>
                                        <td>
                                            <input type="text" name="descricao_personalizada[<?php echo $index; ?>]" class="form-control" 
                                                   value="<?php echo htmlspecialchars($trans['descricao']); ?>" placeholder="Editar descrição se necessário">
                                        </td>
                                        <td class="<?php echo $trans['tipo'] == 'entrada' ? 'valor-positivo' : 'valor-negativo'; ?>">
                                            <?php echo 'R$ ' . number_format($trans['valor'], 2, ',', '.'); ?>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo $trans['tipo'] == 'entrada' ? 'success' : 'danger'; ?>">
                                                <?php echo $trans['tipo'] == 'entrada' ? 'Entrada' : 'Saída'; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <select name="classificacao[<?php echo $index; ?>]" class="form-control" required>
                                                <option value="">Selecione</option>
                                                <?php if ($trans['tipo'] == 'entrada'): ?>
                                                    <?php foreach ($categorias_entrada as $key => $cat): ?>
                                                        <option value="<?php echo $key; ?>" <?php echo $trans['categoria_sugerida'] == $key ? 'selected' : ''; ?>>
                                                            <?php echo $cat; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <?php foreach ($categorias_saida as $key => $cat): ?>
                                                        <option value="<?php echo $key; ?>" <?php echo $trans['categoria_sugerida'] == $key ? 'selected' : ''; ?>>
                                                            <?php echo $cat; ?>
                                                        </option>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="cliente_id[<?php echo $index; ?>]" class="form-control" onchange="carregarOrcamentos(this.value, <?php echo $index; ?>)">
                                                <option value="">Nenhum</option>
                                                <?php foreach ($clientes as $cli): ?>
                                                    <option value="<?php echo $cli['id']; ?>"><?php echo htmlspecialchars($cli['nome']); ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select name="orcamento_id[<?php echo $index; ?>]" id="orcamento_<?php echo $index; ?>" class="form-control">
                                                <option value="">Nenhum</option>
                                                <?php foreach ($orcamentos as $orc): ?>
                                                    <option value="<?php echo $orc['id']; ?>">
                                                        <?php echo $orc['numero'] . ' - ' . htmlspecialchars($orc['cliente_nome']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                         </td>
                                     </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div style="margin-top: 30px; text-align: right;">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fas fa-save"></i> Salvar e Importar
                        </button>
                        <a href="importar_extrato.php" class="btn btn-secondary btn-lg">Cancelar</a>
                    </div>
                </form>

                <script>
                    function carregarOrcamentos(clienteId, index) {
                        if (!clienteId || clienteId === '') return;
                        
                        fetch('ajax_orcamentos.php?cliente_id=' + clienteId)
                            .then(response => response.json())
                            .then(data => {
                                const orcamentoSelect = document.getElementById('orcamento_' + index);
                                orcamentoSelect.innerHTML = '<option value="">Nenhum</option>';
                                data.forEach(orc => {
                                    orcamentoSelect.innerHTML += `<option value="${orc.id}">${orc.numero} - ${orc.cliente_nome}</option>`;
                                });
                            })
                            .catch(error => console.error('Erro:', error));
                    }
                </script>

            <?php else: ?>
                
                <div class="page-header">
                    <h1><i class="fas fa-cloud-upload-alt"></i> Importar Extrato Bancário</h1>
                    <div>
                        <a href="financeiro.php" class="btn btn-info"><i class="fas fa-chart-line"></i> Financeiro</a>
                    </div>
                </div>

                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    <strong>Como exportar do Nubank:</strong>
                    <ol style="margin-top: 10px; margin-left: 20px;">
                        <li>Acesse o aplicativo do Nubank</li>
                        <li>Vá até a <strong>NuConta</strong> ou <strong>Cartão de Crédito</strong></li>
                        <li>Clique no ícone de <strong>compartilhar/exportar</strong> (3 pontinhos)</li>
                        <li>Selecione <strong>Exportar extrato</strong> e escolha o formato <strong>OFX</strong> (recomendado)</li>
                        <li>Envie o arquivo abaixo</li>
                    </ol>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-upload"></i> Upload do Extrato</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data" id="form-upload">
                            <div class="upload-area" id="upload-area">
                                <i class="fas fa-file-invoice-dollar" style="font-size: 48px; color: #6c757d; margin-bottom: 15px;"></i>
                                <p><strong>Clique ou arraste o arquivo aqui</strong></p>
                                <p class="text-muted" style="font-size: 12px;">Formatos aceitos: OFX, OFC, CSV</p>
                                <input type="file" name="arquivo_extrato" id="arquivo_extrato" accept=".ofx,.ofc,.csv" style="display: none;">
                                <button type="button" class="btn btn-primary" onclick="document.getElementById('arquivo_extrato').click()">
                                    <i class="fas fa-folder-open"></i> Selecionar Arquivo
                                </button>
                            </div>
                            <div id="file-info" style="margin-top: 15px; display: none;"></div>
                            <div style="margin-top: 30px; text-align: right;">
                                <button type="submit" class="btn btn-success btn-lg" id="btn-submit" style="display: none;">
                                    <i class="fas fa-upload"></i> Processar Extrato
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-lightbulb"></i> Dicas para melhor classificação da IA</h3>
                    </div>
                    <div class="card-body">
                        <ul style="margin-left: 20px;">
                            <li><strong>Saídas:</strong> A IA identifica automaticamente compras de materiais, fornecedores, funcionários, impostos, aluguel, energia, água, internet e marketing</li>
                            <li><strong>Entradas:</strong> Identifica vendas, cobranças e pagamentos de clientes</li>
                            <li><strong>Confiança alta (verde):</strong> Provavelmente está correta</li>
                            <li><strong>Confiança baixa (vermelha):</strong> Revise manualmente</li>
                            <li><strong>Vincule a um cliente:</strong> Para associar a transação a um cliente específico</li>
                            <li><strong>Vincule a um orçamento:</strong> Para pagamentos de orçamentos aprovados</li>
                        </ul>
                    </div>
                </div>

                <script>
                    const uploadArea = document.getElementById('upload-area');
                    const fileInput = document.getElementById('arquivo_extrato');
                    const fileInfo = document.getElementById('file-info');
                    const submitBtn = document.getElementById('btn-submit');
                    
                    uploadArea.addEventListener('click', () => fileInput.click());
                    uploadArea.addEventListener('dragover', (e) => {
                        e.preventDefault();
                        uploadArea.classList.add('drag-over');
                    });
                    uploadArea.addEventListener('dragleave', () => {
                        uploadArea.classList.remove('drag-over');
                    });
                    uploadArea.addEventListener('drop', (e) => {
                        e.preventDefault();
                        uploadArea.classList.remove('drag-over');
                        const file = e.dataTransfer.files[0];
                        if (file && (file.name.endsWith('.ofx') || file.name.endsWith('.ofc') || file.name.endsWith('.csv'))) {
                            fileInput.files = e.dataTransfer.files;
                            mostrarArquivo(file);
                        } else {
                            alert('Formato inválido. Use OFX, OFC ou CSV.');
                        }
                    });
                    
                    fileInput.addEventListener('change', (e) => {
                        if (e.target.files.length > 0) {
                            mostrarArquivo(e.target.files[0]);
                        }
                    });
                    
                    function mostrarArquivo(file) {
                        fileInfo.style.display = 'block';
                        fileInfo.innerHTML = `
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i>
                                Arquivo selecionado: <strong>${file.name}</strong> (${(file.size / 1024).toFixed(2)} KB)
                            </div>
                        `;
                        submitBtn.style.display = 'inline-flex';
                    }
                </script>

            <?php endif; ?>

        </main>
    </div>
</body>
</html>